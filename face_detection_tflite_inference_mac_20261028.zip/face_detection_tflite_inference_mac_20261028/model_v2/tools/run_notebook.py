"""Notebook execution only: all model/data/training/scientific code lives in .ipynb files."""
import argparse
import asyncio
import ctypes
import faulthandler
import os
from pathlib import Path
import re
import sys
import time

import nbformat
from nbclient import NotebookClient


def compact_stream(output):
    """Keep completed lines and the last carriage-return update, as a terminal does."""
    if output.get('output_type') == 'stream' and '\r' in output.get('text', ''):
        output['text'] = re.sub(r'.*\r(?=[^\n])', '', output['text'])


def compact_cell_streams(cell):
    merged = []
    for output in cell.get('outputs', []):
        if (output.get('output_type') == 'stream' and merged
                and merged[-1].get('output_type') == 'stream'
                and merged[-1].get('name') == output.get('name')):
            merged[-1]['text'] += output['text']
            compact_stream(merged[-1])
        else:
            merged.append(output)
            compact_stream(output)
    if 'outputs' in cell:
        cell['outputs'] = merged


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('notebook', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    source = args.notebook.resolve()
    if not source.is_relative_to(root / 'model_v2') or source.suffix != '.ipynb':
        raise ValueError('Select a notebook inside model_v2.')
    os.chdir(root)
    faulthandler.enable()
    os.environ['PYTHONFAULTHANDLER'] = '1'
    os.environ['JUPYTER_PATH'] = str(root / '.venv-main/share/jupyter')
    os.environ['IPYTHONDIR'] = str(root / '.cache/model_v2_ipython')
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    notebook = nbformat.read(source, as_version=4)
    for cell in notebook.cells:
        compact_cell_streams(cell)
    kernel = notebook.metadata.kernelspec.name
    logs = root / 'model_v2/outputs/runner'
    logs.mkdir(parents=True, exist_ok=True)
    lock = logs / (str(source.relative_to(root)).replace('\\', '__').replace('/', '__') + '.lock')
    # Exclusive lock prevents two writers executing the same notebook simultaneously.
    import psutil
    if lock.exists():
        try:
            pid = int(lock.read_text())
        except ValueError:
            raise RuntimeError(f'Invalid runner lock: {lock}')
        if psutil.pid_exists(pid):
            raise RuntimeError(f'Notebook is already running with PID {pid}')
        lock.unlink()
    with lock.open('x') as stream:
        stream.write(str(os.getpid()))

    last_save = 0.0

    def save():
        nonlocal last_save
        temporary = source.with_suffix('.running.tmp')
        nbformat.write(notebook, temporary)
        for attempt in range(8):
            try:
                os.replace(temporary, source)
                break
            except PermissionError as error:
                if getattr(error, 'winerror', None) not in (5, 32, 33) or attempt == 7:
                    raise
                time.sleep(.01 * 2 ** min(attempt, 5))
        last_save = time.monotonic()

    def starting(cell=None, cell_index=None, **kwargs):
        notebook.metadata['runner'] = {'status': 'running', 'pid': os.getpid(),
                                       'cell': cell_index + 1, 'cells': len(notebook.cells),
                                       'updated_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}

    def completed(cell=None, cell_index=None, **kwargs):
        save()
        print(f'{time.strftime("%H:%M:%S")} saved cell {cell_index + 1}/{len(notebook.cells)}', flush=True)

    class SavingClient(NotebookClient):
        def process_message(self, msg, cell, cell_index):
            result = super().process_message(msg, cell, cell_index)
            if msg.get('msg_type') == 'stream' and cell.get('outputs'):
                compact_cell_streams(cell)
            # Save output while a long training cell is running. Benchmark timing
            # remains free of this periodic notebook serialization.
            if not source.name.startswith('04_cpu_benchmark') and time.monotonic() - last_save >= 30:
                save()
            return result

    outcome = 'failed'
    try:
        print(f'PID={os.getpid()} | kernel={kernel} | {source}', flush=True)
        client = SavingClient(notebook, timeout=None, kernel_name=kernel,
                                resources={'metadata': {'path': str(root)}},
                                on_cell_execute=starting,
                                on_cell_executed=completed)
        client.execute()
        outcome = 'complete'
        print('Notebook completed and saved.', flush=True)
    finally:
        notebook.metadata.setdefault('runner', {})['status'] = outcome
        save()
        lock.unlink(missing_ok=True)
        if sys.platform == 'win32':
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)


if __name__ == '__main__':
    main()
