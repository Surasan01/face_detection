# TFLite face detection บน Mac Apple Silicon

ชุดใช้งานสำหรับ YuNet epoch 11, MTCNN epoch 4 และ RetinaFace MobileNetV1 0.25 epoch 10 ใช้ TFLite FP32 CPU โค้ด inference ทั้งหมดอยู่ใน notebook แยกแต่ละโมเดล พร้อมบันทึก JSON/CSV และ plot ผลทุกรูป

## ไฟล์สำหรับส่งผ่าน GitHub

อัปโหลดไฟล์ต่อไปนี้เข้า repository ที่จะใช้ส่งต่อ:

- `face_detection_tflite_inference_mac_20261028.zip` — แพ็ก TFLite inference
- `face_detection_tflite_inference_mac_20261028.zip.sha256` — checksum ของ ZIP
- คู่มือนี้ สามารถตั้งชื่อเป็น `README.md` ใน repository ได้

บนหน้า repository ใช้ **Add file → Upload files** แล้วอัปโหลดไฟล์ข้างต้น ตาม [คู่มือ GitHub](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository) ซึ่งรองรับการอัปโหลดผ่านเบราว์เซอร์สูงสุด 25 MiB ต่อไฟล์

เมื่อเปิด repository จาก Mac ให้ดาวน์โหลดไฟล์ ZIP และ `.sha256` โดยตรงผ่านปุ่มดาวน์โหลดของแต่ละไฟล์ เก็บทั้งสองไฟล์ไว้ในโฟลเดอร์เดียวกัน

## ตรวจและแตกไฟล์บน Mac

เปิด Terminal ในโฟลเดอร์ที่ดาวน์โหลดไฟล์ เช่น `Downloads`:

```bash
cd ~/Downloads
shasum -a 256 -c face_detection_tflite_inference_mac_20261028.zip.sha256
unzip face_detection_tflite_inference_mac_20261028.zip
cd face_detection_tflite_inference_mac_20261028
```

คำสั่งตรวจ checksum ต้องแสดง `OK` สำหรับ ZIP นี้ ค่า SHA256 อยู่ในไฟล์ `.zip.sha256` ที่ดาวน์โหลดมาคู่กัน

## ติดตั้ง dependencies

ใช้ Python 3.12 สำหรับ Apple Silicon (`uname -m` แสดง `arm64`) สร้าง environment ใหม่บน Mac:

```bash
python3.12 -m venv .venv-main
.venv-main/bin/python -m pip install -r requirements.txt
.venv-main/bin/python -m pip check
.venv-main/bin/python -m ipykernel install --prefix .venv-main --name face-detection-tflite --display-name "Python (Face detection TFLite)"
```

เวอร์ชัน dependencies ถูกระบุใน requirements ภายใน ZIP ใช้ TensorFlow 2.16.1 สำหรับเรียก TFLite Interpreter โค้ด inference ใช้ CPU และไม่มี dependency ของ PyTorch/ONNX

## รันภาพตัวอย่าง

รันจากโฟลเดอร์แพ็กที่แตกแล้ว โดยเลือกโมเดลที่ต้องการ:

```bash
.venv-main/bin/python -X utf8 -u model_v2/tools/run_notebook.py model_v2/deployment_tflite/inference/01_yunet_inference.ipynb
```

```bash
.venv-main/bin/python -X utf8 -u model_v2/tools/run_notebook.py model_v2/deployment_tflite/inference/02_mtcnn_inference.ipynb
```

```bash
.venv-main/bin/python -X utf8 -u model_v2/tools/run_notebook.py model_v2/deployment_tflite/inference/03_retinaface_inference.ipynb
```

ค่าเริ่มต้นใช้ภาพตัวอย่างที่แตกต่างกัน 7 ภาพ, input 480×640 (กว้าง×สูง), confidence 0.50 และ CPU 4 threads ทุกโมเดลใช้ภาพชุดเดียวกันเพื่อเปรียบเทียบผล

## รันภาพของคุณ

ตัวอย่าง YuNet: เปลี่ยน path เป็นโฟลเดอร์ภาพของคุณ รองรับโฟลเดอร์ย่อยด้วย

```bash
FD_INPUT="/Users/yourname/Pictures/faces" .venv-main/bin/python -X utf8 -u model_v2/tools/run_notebook.py model_v2/deployment_tflite/inference/01_yunet_inference.ipynb
```

สำหรับ MTCNN และ RetinaFace เปลี่ยนชื่อ notebook ในคำสั่งเดียวกันเป็น `02_mtcnn_inference.ipynb` หรือ `03_retinaface_inference.ipynb`

หากเปิดผ่าน VS Code ให้เลือก kernel จาก `.venv-main/bin/python` เปลี่ยน `INPUT_PATH` ในเซลล์ตั้งค่า แล้ว Run All

## ดูผล

- notebook ไฟล์ที่รันจะมี outputs พร้อม plot ทุกภาพ แบ่งหลายหน้าหากมีเกิน 6 ภาพ
- ผลรายภาพอยู่ `inference_outputs/<model>/tflite_<size>_<timestamp>/`
- `annotated/`: ภาพพร้อมกรอบเขียว = ใบหน้า, จุดส้ม = landmarks 5 จุด, เลขเหลือง = confidence
- `predictions/`: JSON มี bbox, confidence และพิกัด landmarks บนภาพต้นฉบับที่ปรับ EXIF orientation แล้ว
- `images.csv`, `detections.csv`, `summary.json`, `errors.json` และ `plotted_images.json`: ตารางผล สถานะ และรายชื่อภาพที่แสดง

รายละเอียด output และตัวเลือกเพิ่มเติมอยู่ `model_v2/deployment_tflite/inference/README.md` ภายในแพ็ก

ผลที่บันทึกมาจากการทดสอบ Windows CPU ครบทั้ง 3 โมเดล × 7 ภาพ โมเดลและ notebook ถูกเตรียมสำหรับ Apple Silicon; การทดสอบบน Mac จริงเป็นขั้นถัดไป และตัวอย่าง 7 ภาพนี้ใช้สาธิต inference

รายชื่อ dependencies พร้อมเวอร์ชันและหน้าที่อยู่ [DEPENDENCIES.md](DEPENDENCIES.md) และรายการติดตั้งอยู่ [requirements-mac.txt](requirements-mac.txt) ที่หน้าแรกของแพ็ก
