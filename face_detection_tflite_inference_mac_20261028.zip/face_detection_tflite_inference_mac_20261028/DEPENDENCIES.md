# Dependencies — TFLite inference บน Mac Apple Silicon

ใช้ Python **3.12**, architecture **arm64**, CPU runtime รุ่นของ Python ที่ใช้ตรวจรันบน Windows คือ 3.12.13 ส่วนการรันบน Mac จริงเป็นขั้นถัดไป

## ติดตั้งจากโฟลเดอร์รากของแพ็ก

```bash
python3.12 -m venv .venv-main
.venv-main/bin/python -m pip install -r requirements.txt
.venv-main/bin/python -m pip check
.venv-main/bin/python -m ipykernel install --prefix .venv-main --name face-detection-tflite --display-name "Python (Face detection TFLite)"
```

`requirements.txt` เรียก `requirements-mac.txt` ซึ่ง pin เวอร์ชันแพ็กเกจหลักครบดังตาราง ไฟล์ `model_v2/deployment_tflite/inference/requirements-mac.txt` เป็นสำเนารายการเดียวกันสำหรับคำสั่งเดิม

| แพ็กเกจ | เวอร์ชัน | หน้าที่ |
| --- | --- | --- |
| `tensorflow` | `2.16.1` | TFLite Interpreter สำหรับ CPU |
| `keras` | `3.3.3` | ส่วนประกอบของ TensorFlow runtime |
| `numpy` | `1.26.4` | array, preprocessing, decode และ NMS |
| `pandas` | `2.2.2` | ตารางผลและ CSV |
| `pillow` | `10.2.0` | อ่านภาพ, EXIF orientation, resize และวาดผล |
| `numba` | `0.61.2` | เร่ง NMS ฝั่ง CPU |
| `llvmlite` | `0.44.0` | LLVM runtime ที่ numba ใช้ |
| `matplotlib` | `3.8.4` | plot ผลทุกภาพใน notebook |
| `protobuf` | `4.25.9` | dependency ของ TensorFlow |
| `ml-dtypes` | `0.3.2` | ชนิดข้อมูลของ TensorFlow |
| `nbformat` | `5.10.4` | อ่านและบันทึกไฟล์ ipynb |
| `nbclient` | `0.10.2` | รันเซลล์ notebook จาก terminal |
| `ipykernel` | `6.29.5` | Python kernel สำหรับ notebook |
| `psutil` | `6.1.1` | ตรวจ process และป้องกันการรัน notebook ซ้ำ |
| `tqdm` | `4.66.5` | progress bar |

pip ติดตั้ง dependencies ย่อยให้อัตโนมัติตาม Python และระบบปฏิบัติการ เช่น IPython, jupyter-client และ jupyter-core ตารางนี้เป็นเวอร์ชันหลักที่ pin ไว้ ไม่ใช่ lock ของ dependencies ย่อยทั้งหมด

## บันทึกแพ็กเกจที่ติดตั้งจริงบน Mac

หลังติดตั้งและทดสอบบน Mac ให้เก็บเวอร์ชันทั้งหมดจาก environment ของเครื่องนั้น:

```bash
.venv-main/bin/python --version
.venv-main/bin/python -m pip check
.venv-main/bin/python -m pip freeze > installed-packages-mac.txt
```

เก็บ `installed-packages-mac.txt` คู่กับผลทดสอบ Mac เพื่อใช้ทำซ้ำ environment

## ไฟล์โมเดลที่รวมมาแล้ว

- YuNet epoch 11: TFLite สำหรับ 640×480, 640×640 และ 480×640
- MTCNN epoch 4: PNet, RNet และ ONet
- RetinaFace MNV1 0.25 epoch 10: TFLite สำหรับ 640×480, 640×640 และ 480×640

รวม `.tflite` 9 ไฟล์ พร้อม SHA256 ใน `TFLITE_MODELS.json` และ `SHA256SUMS.txt` รันภาพตัวอย่างได้ทันทีหลังติดตั้ง dependencies โค้ด inference ใช้ TensorFlow/TFLite CPU

ตรวจอ่านโมเดลและผลรันบน Windows แล้วครบ 3 โมเดล × 7 ภาพ ไฟล์ requirements เตรียมสำหรับ Apple Silicon และต้องติดตั้งใน environment ที่สร้างบน Mac
