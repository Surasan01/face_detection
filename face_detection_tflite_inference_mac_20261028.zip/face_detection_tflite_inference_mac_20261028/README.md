# TFLite FP32 inference — 3 โมเดลสำหรับ Mac Apple Silicon

| Notebook | โมเดล | น้ำหนักต้นทาง |
| --- | --- | --- |
| [01 YuNet](model_v2/deployment_tflite/inference/01_yunet_inference.ipynb) | YuNet | fine-tuned epoch 11 |
| [02 MTCNN](model_v2/deployment_tflite/inference/02_mtcnn_inference.ipynb) | PNet / RNet / ONet | epoch 4 |
| [03 RetinaFace](model_v2/deployment_tflite/inference/03_retinaface_inference.ipynb) | MobileNetV1 0.25 | epoch 10 |

ใช้ TFLite CPU อย่างเดียว แต่ละ notebook มี interpreter, preprocessing/decode/NMS, บันทึก JSON/CSV และ plot ผลทุกรูปในเซลล์ ไม่ต้องมี labels หรือรัน converter ก่อน

## ติดตั้ง

แตก ZIP เปิด terminal แบบ ARM64 ที่โฟลเดอร์แพ็ก ใช้ Python 3.12 และไฟล์ requirements สำหรับ inference โดยเฉพาะ:

```bash
python3.12 -m venv .venv-main
.venv-main/bin/python -m pip install -r model_v2/deployment_tflite/inference/requirements-mac.txt
.venv-main/bin/python -m ipykernel install --prefix .venv-main --name face-detection-tflite --display-name "Python (Face detection TFLite)"
```

Dependencies หลัก: TensorFlow 2.16.1, Keras 3.3.3, NumPy 1.26.4, pandas 2.2.2, Pillow 10.2.0, numba 0.61.2, matplotlib 3.8.4; เวอร์ชันครบอยู่ `model_v2/deployment_tflite/inference/requirements-mac.txt` ในโฟลเดอร์นี้

## เปิด notebook

เลือก kernel `face-detection-tflite` เปลี่ยน `INPUT_PATH` เป็นไฟล์หรือโฟลเดอร์ภาพ แล้ว Run All ถ้าไม่เปลี่ยนจะใช้ภาพ WIDER FACE ที่ไม่ซ้ำกัน 7 ภาพใน `samples/inference_gallery` มีทั้งภาพคนเดียว กลุ่มคน และฝูงชน ทั้ง 3 notebook ใช้ภาพชุดเดียวกันเพื่อดูผลเทียบกันได้ ภาพถูกเลือกตามชนิดฉาก/จำนวน annotations ก่อนรันโมเดล ไม่ได้คัดจากผลที่ตรวจจับได้ดี รายชื่อภาพต้นทางและ hashes อยู่ใน `gallery_manifest.json` ชุดนี้เป็นตัวอย่าง inference ไม่ใช่ผล AP

ค่าเริ่มต้น: input 480×640 (กว้าง×สูง), confidence 0.50, CPU 4 threads, อ่านทุกภาพในโฟลเดอร์ย่อยด้วย เซลล์สุดท้าย plot ทุกภาพที่ประมวลผลสำเร็จ แบ่ง figure ละ 6 ภาพ ปรับ `IMAGES_PER_FIGURE` เพื่อเปลี่ยนจำนวนภาพต่อหน้าได้ จำนวนภาพที่แสดงรวมยังเท่าเดิม

## รันจาก terminal บน Mac

จากโฟลเดอร์แพ็ก เปลี่ยน path ต่อไปนี้เป็นไฟล์หรือโฟลเดอร์ภาพจริง:

```bash
FD_INPUT="/Users/yourname/Pictures/faces" .venv-main/bin/python -X utf8 -u model_v2/tools/run_notebook.py model_v2/deployment_tflite/inference/01_yunet_inference.ipynb
```

```bash
FD_INPUT="/Users/yourname/Pictures/faces" .venv-main/bin/python -X utf8 -u model_v2/tools/run_notebook.py model_v2/deployment_tflite/inference/02_mtcnn_inference.ipynb
```

```bash
FD_INPUT="/Users/yourname/Pictures/faces" .venv-main/bin/python -X utf8 -u model_v2/tools/run_notebook.py model_v2/deployment_tflite/inference/03_retinaface_inference.ipynb
```

ตั้งเพิ่มได้: `FD_INPUT_WH=640x480` หรือ `640x640`, `FD_THRESHOLD=0.5`, `FD_THREADS=4`, `FD_OUTPUT="/Users/yourname/face_results"` ค่าเริ่มต้น input คือ 480x640 หากไม่ใส่ FD_INPUT จะรันภาพตัวอย่าง

## ผลลัพธ์

Notebook บันทึก output รวมภาพ plot ทุกหน้าลงไฟล์เดิม และสร้าง `inference_outputs/<model>/tflite_<size>_<timestamp>/`:

- `annotated/`: PNG พร้อมกรอบเขียว = ใบหน้า, จุดส้ม = 5 landmarks, เลขเหลือง = confidence และ legend ใต้ภาพ
- `predictions/`: JSON รายภาพ มี bbox `[x1,y1,x2,y2]`, confidence และ `landmarks_xy` 5 คู่
- `images.csv`, `detections.csv`: หนึ่งแถวต่อภาพ / ต่อใบหน้า
- `run_manifest.json`, `summary.json`, `errors.json`: model/runtime, TFLite hashes และจำนวนภาพสำเร็จ/อ่านไม่ได้
- `plotted_images.json`: รายชื่อภาพที่ plot ครบตรงกับภาพที่ประมวลผลสำเร็จ

รองรับ JPG/JPEG/PNG/BMP/TIF/TIFF/WebP ที่ Pillow เปิดได้ เก็บโครงสร้างโฟลเดอร์ย่อยและชื่อเต็มเพื่อไม่ให้ไฟล์ชื่อซ้ำทับกัน ปรับ EXIF orientation ก่อน infer; พิกัดอ้างถึงภาพที่ปรับทิศแล้ว, x ไปขวา y ลงล่าง ลำดับจุด 1/2 คือดวงตา, 3 จมูก, 4/5 มุมปาก คงลำดับ output เดิม ภาพไม่มีใบหน้าได้รายการว่างตามปกติ

ค่าเวลาใน images.csv เป็น single-pass ที่มี cold start ได้ ใช้ notebook benchmark สำหรับ mean/P95 มาตรฐาน การตรวจรันที่บันทึกเป็น Windows CPU; ยังไม่ได้ยืนยันเครื่อง Mac จริง
