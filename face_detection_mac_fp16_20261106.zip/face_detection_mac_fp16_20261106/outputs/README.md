ผลแต่ละรอบจะถูกสร้างในโฟลเดอร์ใหม่: ภาพวาดกรอบ, JSON, summary.csv และ gallery.html
