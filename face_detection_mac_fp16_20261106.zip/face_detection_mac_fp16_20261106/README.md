# Face detection — TFLite FP16 บน Mac

แพ็กสำหรับ Apple Silicon ใช้ CPU ผ่าน TFLite ไม่ต้องติดตั้ง PyTorch, CUDA หรือ tensorflow-metal
มี 6 โมเดลที่เลือกหลังเทรน พร้อม 3 input sizes (กว้าง × สูง): 480×640, 640×640, 640×480
MTCNN ใช้ PNet/RNet/ONet ชุดเดียว รองรับ canvas ทั้งสามขนาด

## 1. ติดตั้ง

ใช้ Python 3.12 แบบ arm64 และ macOS 12 ขึ้นไป เปิด Terminal ที่โฟลเดอร์แพ็กนี้:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-mac.txt
python -m inference.check
```

ถ้าไม่มี `python3.12` ให้ติดตั้ง Python 3.12 universal2 จาก python.org หรือใช้ Python 3.12 ขององค์กร
ตรวจ `python -c "import platform; print(platform.machine())"` ต้องเป็น `arm64`
TensorFlow 2.16.1 มี wheel CPython 3.12 macOS arm64:
https://pypi.org/project/tensorflow/2.16.1/
dependencies โดยตรงล็อกเวอร์ชันไว้ ส่วน dependencies ทางอ้อมให้ pip resolve ตาม macOS
การทดสอบที่มาพร้อมแพ็กทำบน Windows CPU; ให้รัน check บน Mac อีกครั้ง

## 2. รันกับภาพของคุณ

วางภาพใน `images/` แล้วรันทุกโมเดลต่อกัน:

```bash
python -m inference.run --model all --input images --size 480x640 --output outputs/all_portrait
open outputs/all_portrait/gallery.html
```

รันทีละโมเดล (ใช้ชื่อจากตารางด้านล่าง):

```bash
python -m inference.run --model yunet --input images --size 480x640 --output outputs/yunet_portrait
python -m inference.run --model retinaface_mnv1_025 --input images --size 640x640 --output outputs/rf1_square
python -m inference.run --model mtcnn --input images --size 640x480 --output outputs/mtcnn_landscape
```

เพิ่ม `--threads 4` เพื่อทดลองจำนวน CPU threads หรือ `--confidence 0.7` เพื่อกรองผลแสดง
ค่าเริ่มต้น confidence=0.5, threads=2; MTCNN ยังมี cascade thresholds 0.6/0.7/0.7
ถ้ารันซ้ำ ให้ใช้ output folder ใหม่ หรือไม่ระบุ `--output` เพื่อสร้างโฟลเดอร์ตามเวลา
ไม่เอารูป output วนกลับมา infer และคงชื่อโฟลเดอร์ย่อย ป้องกันรูปชื่อซ้ำเขียนทับกัน
JPG/PNG/WebP/TIFF/BMP รองรับ; HEIC ให้แปลงเป็น JPG ก่อน

| --model | รุ่น | checkpoint epoch |
|---|---|---|
| mtcnn | MTCNN | 4 |
| yunet | YuNet model_v3 | 12 |
| retinaface_mnv1_025 | RetinaFace MNV1 0.25 | 9 |
| retinaface_mnv2_025 | RetinaFace MNV2 0.25 | 70 |
| retinaface_mnv3_small_025 | RetinaFace MNV3 Small 0.25 | 25 |
| retinaface_mnv4_small_025 | RetinaFace MNV4 Small 0.25 | 52 |

ที่มาและ SHA256 checkpoint อยู่ใน `model_manifest.json` ใช้ตัวเดียวต่อโมเดลตาม Week 4
เลือกก่อน/หลังเทรนด้วยค่าเฉลี่ย NME test ของ COFW/WFLW/300W ที่480×640 ตามเกณฑ์โครงการ

## 3. อ่านผล

- `gallery.html` แสดงรูปผล **ทุกรูป ทุกโมเดลที่รัน** เปิดได้แบบ offline
- กรอบเขียว = ใบหน้า, จุดส้ม = landmark 5 จุด, ตัวเลขเหลือง = confidence
- JSON: `boxes_xyxy_score` เป็น [x1,y1,x2,y2,score]; `landmarks_xy` เป็น [จำนวนหน้า,5,2]
- จุดเรียงตามตำแหน่งภาพ: ตาฝั่งซ้ายภาพ, ตาฝั่งขวาภาพ, จมูก, มุมปากฝั่งซ้ายภาพ, มุมปากฝั่งขวาภาพ
- พิกัดอ้างอิงภาพต้นฉบับหลังจัดทิศทาง EXIF ไม่ใช่ canvas โมเดล; ไม่ clip พิกัดเพื่อเก็บค่าทำนายจริง
- `summary.csv` สรุปจำนวนหน้าและเวลา; `errors.json` แจ้งภาพที่อ่านไม่ได้
- ms ต่อภาพรวม preprocess, network, decode/NMS แต่ไม่รวมอ่านไฟล์/วาด/เซฟ และมี first-call warm-up
  เวลานี้เป็นการใช้งานรอบนั้น ไม่ใช่ผล benchmark ควบคุมสภาพแวดล้อม

## 4. ใช้จาก Python และ Notebook

```python
from inference.detector import Detector
from inference.preprocessing import load_image

model = Detector('yunet', size=(480, 640), threads=2, confidence=0.5)
image = load_image('images/my_photo.jpg')
boxes, landmarks = model(image)
print(boxes.shape, landmarks.shape)
```

Notebook เป็นตัวอย่างเรียก .py ชุดเดียวกันและ plot ผลทุกรูปท้าย notebook:

```bash
python -m pip install -r requirements-notebook.txt
python -m ipykernel install --user --name face-tflite --display-name "Face TFLite FP16"
```

เปิด `notebooks/01_inference_demo.ipynb` ใน VS Code เลือก kernel นี้แล้ว Run All
Notebook ไม่แถมภาพ dataset ให้ใส่ภาพของคุณใน images/ ก่อนรัน
Notebook มีผลตัวอย่างที่รันและบันทึกไว้แล้วจากภาพ WIDER FACE 3 ภาพบน Windows
ผลที่เซฟไว้ใช้ตรวจแพ็กเท่านั้น เมื่อ Run All จะแทนที่ด้วยผลจากภาพที่คุณใส่

### Demo ซ้อน MTCNN กับ RetinaFace

เปิด `notebooks/02_mtcnn_retinaface_overlay_demo.ipynb` แล้ว Run All
ใช้เฉพาะ MTCNN และ RetinaFace MNV1 0.25 วาดกรอบและ landmark บนภาพเดียวกัน:

- ฟ้า เส้นทึบ วงกลมโปร่ง = MTCNN
- ส้ม เส้นประ กากบาท = RetinaFace MNV1 0.25
- แสดงภาพต้นฉบับคู่ภาพซ้อน และซูมทุกหน้าที่อย่างน้อยหนึ่งโมเดลตรวจพบ พร้อมเลขจุด 1–5
- กรอบที่ไม่มีคู่ยังแสดงครบ; การจับคู่ด้วย IoU ใช้จัดภาพซูม ไม่ใช่การวัดความถูกต้อง
- ตั้ง `INPUT`, `SIZE`, `CONFIDENCE` ใน cell แรก ผล PNG/JSON/CSV บันทึกลง `outputs/overlay_<เวลา>/`

Notebook นี้มีผล demo ที่รันไว้แล้วเช่นกัน ภาพไม่มี ground truth จึงใช้เทียบด้วยสายตา
ไม่ใช้ confidence ของสองโมเดลมาตัดสินว่าโมเดลใดแม่นกว่า

## 5. โค้ดอยู่ส่วนไหน

- `detector.py`: โหลดโมเดล, รับภาพ, คืนพิกัดต้นฉบับ
- `preprocessing.py`: EXIF, RGB, letterbox รักษาสัดส่วน เติมขอบดำ
- `yunet.py` / `retinaface.py`: แปลงผล heads เป็นกรอบ/5 จุด
- `mtcnn.py`: image pyramid และ cascade 3 ขั้น
- `runtime.py`: เรียก TFLite; `postprocessing.py`: NMS
- `run.py`: รันโฟลเดอร์; `visualization.py`: วาดผลและ gallery

YuNet/RetinaFace รับ RGB float32 หาร255 รูปทรง [1,H,W,3]; การแปลงสี/scale แบบต้นฉบับอยู่ในกราฟแล้ว
น้ำหนัก FP16 แต่ input/output FP32 ไม่ได้หมายความว่าทุก operation คำนวณ FP16 บน CPU
ไม่ใส่โค้ด train/export/optimizer และไม่ได้เปลี่ยนน้ำหนักเดิมตอนทำแพ็ก
