"""Validate packaged hashes, model input contracts, and all 18 model/size cases."""
from pathlib import Path
import hashlib
import json
import platform
import sys
from PIL import Image
from .detector import Detector, MODEL_NAMES, MANIFEST, PACKAGE_ROOT


def main():
    print('Python:', sys.version.split()[0], '| OS:', platform.system(), '| arch:', platform.machine())
    sums = PACKAGE_ROOT / 'SHA256SUMS.txt'
    if sums.exists():
        for line in sums.read_text(encoding='utf-8').splitlines():
            expected, name = line.split('  ', 1)
            # Notebook outputs/configuration may be edited by the user.
            # The runtime check protects immutable model weights and metadata.
            if not name.startswith('models/'):
                continue
            actual = hashlib.sha256((PACKAGE_ROOT / name).read_bytes()).hexdigest()
            if actual != expected:
                raise RuntimeError(f'Hash mismatch: {name}')
        print('Model hashes: PASS (SHA256SUMS.txt also lists original code files)')
    for name in MODEL_NAMES:
        for size in MANIFEST['sizes']:
            detector = Detector(name, size)
            boxes, landmarks = detector(Image.new('RGB', (257, 391), (0, 0, 0)))
            assert boxes.shape == (len(boxes), 5)
            assert landmarks.shape == (len(boxes), 5, 2)
            print(name, size, 'PASS', flush=True)
    print('All 18 model/input cases passed. Blank-image smoke test; not an accuracy benchmark.')


if __name__ == '__main__':
    main()
