from PIL import ImageDraw, ImageFont
import html
from urllib.parse import quote


def draw_detections(image, boxes, landmarks):
    canvas = image.copy()
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.load_default(size=max(12, image.width // 70))
    width = max(2, image.width // 400)
    radius = max(2, image.width // 250)
    for box, points in zip(boxes, landmarks):
        draw.rectangle(tuple(box[:4]), outline='#00dd55', width=width)
        draw.text((max(0, box[0]), max(0, box[1] - 20)), f'{box[4]:.3f}',
                  fill='yellow', font=font, stroke_width=1, stroke_fill='black')
        for x, y in points:
            draw.ellipse((x-radius, y-radius, x+radius, y+radius), fill='orange')
    draw.text((8, 8), 'Green: face | Orange: 5 landmarks | Yellow: confidence',
              fill='white', font=font, stroke_width=1, stroke_fill='black')
    return canvas


def write_gallery(output, records):
    cards = []
    for row in records:
        title = html.escape(f"{row['model']} | {row['image']} | {row['faces']} faces")
        path = quote(row['annotated_image'], safe='/')
        cards.append(f'<figure><figcaption>{title}</figcaption><img loading="lazy" src="{path}"></figure>')
    content = ('<!doctype html><html><meta charset="utf-8"><title>All inference results</title>'
               '<style>body{font:16px sans-serif;margin:24px;background:#fafafa}'
               'main{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px}'
               'figure{margin:0;padding:12px;background:white}img{width:100%;height:auto}'
               'figcaption{margin-bottom:10px;overflow-wrap:anywhere}</style>'
               '<h1>All inference results</h1><main>' + ''.join(cards) + '</main></html>')
    (output / 'gallery.html').write_text(content, encoding='utf-8')
