from pathlib import Path
import json
import time
import numpy as np
from .runtime import LiteNetwork
from .preprocessing import letterbox
from . import yunet, retinaface, mtcnn

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
MANIFEST = json.loads((PACKAGE_ROOT / 'model_manifest.json').read_text(encoding='utf-8'))
MODEL_NAMES = list(MANIFEST['models'])


class Detector:
    def __init__(self, model='yunet', size=(480, 640), threads=2, confidence=0.5):
        if model not in MODEL_NAMES:
            raise ValueError(f'Unknown model: {model}. Available: {MODEL_NAMES}')
        if list(size) not in MANIFEST['sizes']:
            raise ValueError('Supported W x H: 480x640, 640x640, 640x480')
        if not 0 <= confidence <= 1:
            raise ValueError('confidence must be between 0 and 1')
        if threads < 1:
            raise ValueError('threads must be positive')
        self.model = model
        self.size = tuple(size)
        self.confidence = confidence
        self.last_ms = 0.0
        folder = PACKAGE_ROOT / 'models' / model
        if model == 'mtcnn':
            self.stages = {}
            for stage, side in [('pnet', 32), ('rnet', 24), ('onet', 48)]:
                self.stages[stage] = LiteNetwork(
                    folder / f'{stage}.tflite', 'image', threads,
                    initial_shape=[1, side, side, 3]
                )
        else:
            folder = folder / f'{size[0]}x{size[1]}'
            self.network = LiteNetwork(folder / 'model.tflite', 'images', threads)
            expected = (1, size[1], size[0], 3)
            if self.network.shape != expected:
                raise ValueError(f'Model input {self.network.shape} != {expected}')
            info = json.loads((folder / 'conversion.json').read_text(encoding='utf-8'))
            self.output_names = info['files'][0]['output_names']

    def cascade_stage(self, stage, batch):
        chunks = []
        for start in range(0, len(batch), 512):
            chunks.append(self.stages[stage](batch[start:start + 512]))
        result = {}
        for key in chunks[0]:
            result[key] = np.concatenate([chunk[key] for chunk in chunks])
        return result

    def __call__(self, image):
        """Return Nx5 [x1,y1,x2,y2,score], Nx5x2 landmarks in original image pixels.

        Dense graphs accept RGB float32 /255, NHWC. Their graph contains the
        original training colour/normalization conversion; do not repeat it.
        Letterbox is black, aspect-preserving, with the evaluation half-pixel
        inverse landmark mapping. Coordinates are not clipped for evaluation.
        """
        started = time.perf_counter()
        canvas, (sx, sy, left, top) = letterbox(image.convert('RGB'), self.size)
        pixels = np.asarray(canvas, dtype=np.float32)
        if self.model == 'mtcnn':
            boxes, points = mtcnn.mtcnn_numpy(pixels, self.cascade_stage)
        else:
            values = self.network(pixels[None] / np.float32(255))
            outputs = {}
            for index, name in enumerate(self.output_names):
                outputs[name] = values[f'output_{index:02d}']
            if self.model == 'yunet':
                boxes, points = yunet.decode(outputs, self.size)
            else:
                outputs = {'box': outputs['boxes'], 'class': outputs['class_logits'],
                           'landmark': outputs['landmarks']}
                boxes, points = retinaface.decode(outputs, self.size)
        boxes = np.asarray(boxes, dtype=float).reshape(-1, 5)
        points = np.asarray(points, dtype=float).reshape(-1, 5, 2)
        boxes[:, :4] = (boxes[:, :4] - [left, top, left, top]) / [sx, sy, sx, sy]
        points = (points - [left, top] + 0.5) / [sx, sy] - 0.5
        valid = np.isfinite(boxes).all(1) & np.isfinite(points).all((1, 2))
        valid &= (boxes[:, 2:4] > boxes[:, :2]).all(1)
        valid &= boxes[:, 4] >= self.confidence
        boxes, points = boxes[valid], points[valid]
        order = np.argsort(-boxes[:, 4], kind='stable')
        self.last_ms = (time.perf_counter() - started) * 1000
        return boxes[order], points[order]
