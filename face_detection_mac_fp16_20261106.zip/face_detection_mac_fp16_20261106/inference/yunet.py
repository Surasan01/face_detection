"""Decode boxes, confidence and five landmarks from exported network outputs."""
import math
import numpy as np
from .postprocessing import nms

RETINA_CFG = {'steps': [8, 16, 32], 'min_sizes': [[16, 32], [64, 128], [256, 512]]}

def sigmoid_np(x):
    x = np.asarray(x, np.float32)
    return np.exp(-np.logaddexp(np.float32(0), -x)).astype(np.float32)

def decode(output, size, score_floor=0.001, top_k=5000, nms_iou=0.3):
    cls = np.concatenate([output[f'cls_{s}_logits'] for s in [8, 16, 32]], axis=1)[0, :, 0]
    obj = np.concatenate([output[f'obj_{s}_logits'] for s in [8, 16, 32]], axis=1)[0, :, 0]
    raw = np.concatenate([output[f'bbox_{s}'] for s in [8, 16, 32]], axis=1)[0]
    lm = np.concatenate([output[f'kps_{s}'] for s in [8, 16, 32]], axis=1)[0]
    grids = []
    strides = []
    w, h = size
    for stride in [8, 16, 32]:
        yy, xx = np.meshgrid(np.arange(h // stride), np.arange(w // stride), indexing='ij')
        grids.append(np.stack([xx, yy], axis=-1).reshape(-1, 2))
        strides.append(np.full((xx.size, 1), stride))
    grid = np.concatenate(grids).astype(np.float32)
    stride = np.concatenate(strides).astype(np.float32)
    score = np.sqrt(sigmoid_np(cls) * sigmoid_np(obj))
    center = (raw[:, :2] + grid) * stride
    wh = np.exp(np.clip(raw[:, 2:], -15, 15)) * stride
    boxes = np.concatenate([center - wh / 2, center + wh / 2], axis=1)
    points = (lm.reshape(-1, 5, 2) + grid[:, None]) * stride[:, None]
    ids = np.flatnonzero(score > score_floor)
    ids = ids[np.argsort(-score[ids], kind='stable')[:top_k]]
    pred = np.column_stack([boxes[ids], score[ids]])
    points = points[ids]
    keep = nms(pred, nms_iou)
    return (pred[keep], points[keep])
