from pathlib import Path
import os
import numpy as np

os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
import tensorflow as tf


class LiteNetwork:
    """Signature names and fixed image shape are validated before inference."""

    def __init__(self, path, input_name, threads=2, initial_shape=None):
        self.interpreter = tf.lite.Interpreter(
            model_content=Path(path).read_bytes(), num_threads=threads
        )
        if initial_shape is not None:
            index = self.interpreter.get_input_details()[0]['index']
            self.interpreter.resize_tensor_input(index, initial_shape, strict=False)
        self.interpreter.allocate_tensors()
        self.shape = tuple(self.interpreter.get_input_details()[0]['shape'])
        self.input_name = input_name
        self.runner = self.interpreter.get_signature_runner()

    def __call__(self, pixels):
        return self.runner(**{self.input_name: np.asarray(pixels, dtype=np.float32)})
