import numpy as np


def nms(boxes, threshold):
    """Inclusive-coordinate IoU, matching the evaluation protocol (+1 pixel)."""
    boxes = np.asarray(boxes, dtype=np.float32)
    order = np.argsort(-boxes[:, 4], kind='stable')
    area = np.prod(boxes[:, 2:4] - boxes[:, :2] + 1, axis=1)
    kept = []
    while len(order):
        current = order[0]
        kept.append(current)
        rest = order[1:]
        low = np.maximum(boxes[current, :2], boxes[rest, :2])
        high = np.minimum(boxes[current, 2:4], boxes[rest, 2:4])
        intersection = np.prod(np.maximum(high - low + 1, 0), axis=1)
        union = area[current] + area[rest] - intersection
        overlap = np.divide(intersection, union, out=np.zeros_like(intersection), where=union > 0)
        order = rest[overlap <= threshold]
    return np.asarray(kept, dtype=np.int64)
