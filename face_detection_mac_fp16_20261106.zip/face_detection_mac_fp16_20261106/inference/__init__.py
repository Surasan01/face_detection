"""Portable TFLite FP16 face detection; no PyTorch required."""
