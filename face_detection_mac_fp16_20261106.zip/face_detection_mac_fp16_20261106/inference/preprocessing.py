from PIL import Image, ImageOps


def load_image(path):
    """Return RGB pixels in the displayed orientation, including phone EXIF rotation."""
    with Image.open(path) as source:
        return ImageOps.exif_transpose(source).convert('RGB')

def letterbox(image, size=(640, 480)):
    """RGB image -> fixed canvas without distorting aspect ratio; W,H convention."""
    ratio = min(size[0] / image.width, size[1] / image.height)
    resized = image.resize((max(1, round(image.width * ratio)), max(1, round(image.height * ratio))), Image.Resampling.BILINEAR)
    left, top = ((size[0] - resized.width) // 2, (size[1] - resized.height) // 2)
    canvas = Image.new('RGB', size, (0, 0, 0))
    canvas.paste(resized, (left, top))
    return (canvas, (resized.width / image.width, resized.height / image.height, left, top))
