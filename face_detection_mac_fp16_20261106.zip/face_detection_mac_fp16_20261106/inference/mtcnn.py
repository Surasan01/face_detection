"""MTCNN cascade in NumPy. Only PNet/RNet/ONet run in TFLite.

PNet uses an image pyramid; RNet and ONet use 24x24 and 48x48 crops.
The cascade keeps the evaluation thresholds 0.6 / 0.7 / 0.7.
"""
import numpy as np
def area_resize_np(image, size_hw):
    oh, ow = size_hw
    ih, iw = image.shape[:2]
    y0 = np.floor(np.arange(oh) * ih / oh).astype(int)
    y1 = np.ceil((np.arange(oh) + 1) * ih / oh).astype(int)
    x0 = np.floor(np.arange(ow) * iw / ow).astype(int)
    x1 = np.ceil((np.arange(ow) + 1) * iw / ow).astype(int)
    summed = np.pad(np.asarray(image, np.float64), ((1, 0), (1, 0), (0, 0))).cumsum(0).cumsum(1)
    total = summed[y1[:, None], x1] - summed[y0[:, None], x1] - summed[y1[:, None], x0] + summed[y0[:, None], x0]
    return (total / ((y1 - y0)[:, None] * (x1 - x0))[..., None]).astype(np.float32)

def cascade_nms(boxes, threshold, minimum=False):
    if not len(boxes):
        return np.empty(0, np.int64)
    if minimum:
        order = np.argsort(boxes[:, 4])
        margin = np.float32(1.0)
    else:
        order = np.argsort(-boxes[:, 4], kind='stable')[::-1]
        margin = np.float32(0.0)
    area = (boxes[:, 2] - boxes[:, 0] + margin) * (boxes[:, 3] - boxes[:, 1] + margin)
    keep = []
    while len(order):
        i = order[-1]
        keep.append(i)
        rest = order[:-1]
        lo = np.maximum(boxes[i, :2], boxes[rest, :2])
        hi = np.minimum(boxes[i, 2:4], boxes[rest, 2:4])
        wh = np.maximum(np.float32(0), hi - lo + margin)
        inter = wh[:, 0] * wh[:, 1]
        if minimum:
            denominator = np.minimum(area[i], area[rest])
        else:
            denominator = area[i] + area[rest] - inter
        overlap = np.divide(inter, denominator, out=np.zeros_like(inter), where=denominator > 0)
        order = rest[overlap <= threshold]
    return np.asarray(keep, np.int64)

def square_boxes(boxes):
    boxes = boxes.copy()
    wh = boxes[:, 2:4] - boxes[:, :2]
    side = wh.max(axis=1)
    boxes[:, :2] += wh * np.float32(0.5) - side[:, None] * np.float32(0.5)
    boxes[:, 2:4] = boxes[:, :2] + side[:, None]
    return boxes

def regress_boxes(boxes, regression, inclusive=True):
    boxes = boxes.copy()
    margin = np.float32(0.0)
    if inclusive:
        margin = np.float32(1.0)
    wh = boxes[:, 2:4] - boxes[:, :2] + margin
    boxes[:, :4] += regression * np.column_stack([wh, wh])
    return boxes

def cascade_crops(image, boxes, side):
    h, w = image.shape[:2]
    integer = np.trunc(boxes[:, :4]).astype(int)
    integer[:, 0] = np.maximum(integer[:, 0], 1)
    integer[:, 1] = np.maximum(integer[:, 1], 1)
    integer[:, 2] = np.minimum(integer[:, 2], w)
    integer[:, 3] = np.minimum(integer[:, 3], h)
    ids = np.flatnonzero((integer[:, 2] >= integer[:, 0]) & (integer[:, 3] >= integer[:, 1]))
    crops = [area_resize_np(image[y1 - 1:y2, x1 - 1:x2], (side, side)) for x1, y1, x2, y2 in integer[ids]]
    if crops:
        data = np.stack(crops)
    else:
        data = np.empty((0, side, side, 3), np.float32)
    return (ids, (data - np.float32(127.5)) * np.float32(0.0078125))

def mtcnn_numpy(image, heads):
    image = np.asarray(image, np.float32)
    h, w = image.shape[:2]
    scale = 0.6
    small = min(h, w) * scale
    proposals = []
    while small >= 12:
        resized = area_resize_np(image, (int(h * scale + 1), int(w * scale + 1)))
        out = heads('pnet', (resized[None] - np.float32(127.5)) * np.float32(0.0078125))
        y, x = np.where(out['prob'][0, 1] >= 0.6)
        xy = np.stack([x, y], axis=1).astype(np.float32)
        boxes = np.column_stack([np.floor((2 * xy + 1) / np.float32(scale)), np.floor((2 * xy + 12) / np.float32(scale)), out['prob'][0, 1, y, x], out['box'][0].transpose(1, 2, 0)[y, x]])
        proposals.append(boxes[cascade_nms(boxes, 0.5)])
        scale *= 0.709
        small *= 0.709
    if proposals:
        boxes = np.concatenate(proposals)
    else:
        boxes = np.empty((0, 9), np.float32)
    if not len(boxes):
        return (np.empty((0, 5)), np.empty((0, 5, 2)))
    boxes = boxes[cascade_nms(boxes, 0.7)]
    boxes = square_boxes(regress_boxes(boxes[:, :5], boxes[:, 5:9], inclusive=False))
    ids, crops = cascade_crops(image, boxes, 24)
    boxes = boxes[ids]
    if not len(boxes):
        return (np.empty((0, 5)), np.empty((0, 5, 2)))
    out = heads('rnet', crops)
    score = out['prob'][:, 1]
    passed = score > 0.7
    boxes = np.column_stack([boxes[passed, :4], score[passed]])
    reg = out['box'][passed]
    keep = cascade_nms(boxes, 0.7)
    boxes = square_boxes(regress_boxes(boxes[keep], reg[keep]))
    ids, crops = cascade_crops(image, boxes, 48)
    boxes = boxes[ids]
    if not len(boxes):
        return (np.empty((0, 5)), np.empty((0, 5, 2)))
    out = heads('onet', crops)
    score = out['prob'][:, 1]
    passed = score > 0.7
    boxes = np.column_stack([boxes[passed, :4], score[passed]])
    raw = out['landmark'][passed]
    reg = out['box'][passed]
    wh = boxes[:, 2:4] - boxes[:, :2] + 1
    points = np.stack([wh[:, 0, None] * raw[:, :5] + boxes[:, 0, None] - 1, wh[:, 1, None] * raw[:, 5:] + boxes[:, 1, None] - 1], axis=-1)
    boxes = regress_boxes(boxes, reg)
    keep = cascade_nms(boxes, 0.7, minimum=True)
    return (boxes[keep], points[keep])
