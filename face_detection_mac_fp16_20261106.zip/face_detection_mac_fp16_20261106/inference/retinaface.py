"""Decode boxes, confidence and five landmarks from exported network outputs."""
import math
import numpy as np
from .postprocessing import nms

RETINA_CFG = {'steps': [8, 16, 32], 'min_sizes': [[16, 32], [64, 128], [256, 512]]}

def decode(output, size, score_floor=0.001, top_k=5000, nms_iou=0.3):
    w, h = size
    anchors = []
    for step, sizes in zip(RETINA_CFG['steps'], RETINA_CFG['min_sizes']):
        for y in range(math.ceil(h / step)):
            for x in range(math.ceil(w / step)):
                for side in sizes:
                    anchors.append([(x + 0.5) * step / w, (y + 0.5) * step / h, side / w, side / h])
    prior = np.asarray(anchors, np.float32)
    loc = output['box'][0]
    logit = output['class'][0]
    lm = output['landmark'][0]
    exp = np.exp(logit - logit.max(axis=1, keepdims=True))
    score = (exp / exp.sum(axis=1, keepdims=True))[:, 1]
    ids = np.flatnonzero(score > score_floor)
    ids = ids[np.argsort(-score[ids], kind='stable')[:top_k]]
    p = prior[ids]
    raw = loc[ids]
    center = p[:, :2] + raw[:, :2] * np.float32(0.1) * p[:, 2:]
    wh = p[:, 2:] * np.exp(raw[:, 2:] * np.float32(0.2))
    scale = np.asarray([w, h, w, h], np.float32)
    boxes = np.concatenate([center - wh / 2, center + wh / 2], axis=1) * scale
    points = (p[:, None, :2] + lm[ids].reshape(-1, 5, 2) * np.float32(0.1) * p[:, None, 2:]) * np.asarray(size, np.float32)
    pred = np.column_stack([boxes, score[ids]])
    keep = nms(pred, nms_iou)
    return (pred[keep], points[keep])
