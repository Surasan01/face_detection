"""Run from the package folder: python -m inference.run --model all --input images"""
from pathlib import Path
import argparse
import csv
import json
import time
from .detector import Detector, MODEL_NAMES, MANIFEST
from .preprocessing import load_image
from .visualization import draw_detections, write_gallery

EXTENSIONS = {'.jpg', '.jpeg', '.png', '.bmp', '.webp', '.tif', '.tiff'}


def run_folder(input_path, output_path, models, size=(480, 640), threads=2, confidence=0.5):
    source = Path(input_path).resolve()
    output = Path(output_path).resolve()
    if source == output:
        raise ValueError('Input and output must be different folders')
    if source.is_file():
        paths = [source]
        base = source.parent
    elif source.is_dir():
        base = source
        paths = sorted(p for p in source.rglob('*') if p.is_file()
                       and p.suffix.lower() in EXTENSIONS and not p.is_relative_to(output))
    else:
        raise FileNotFoundError(source)
    if not paths:
        raise ValueError('No supported images found. Put JPG/PNG images in the input folder.')
    if (output / 'summary.csv').exists():
        raise FileExistsError(f'Use a new output folder to preserve the earlier run: {output}')
    output.mkdir(parents=True, exist_ok=True)
    records = []
    errors = []
    for model in models:
        detector = Detector(model, size, threads, confidence)
        for index, path in enumerate(paths, 1):
            relative = path.relative_to(base)
            try:
                image = load_image(path)
            except Exception as error:
                errors.append({'image': relative.as_posix(), 'model': model, 'error': str(error)})
                print(f'SKIP {relative}: {error}', flush=True)
                continue
            boxes, points = detector(image)
            target = output / model / relative.parent / (relative.name + '.png')
            target.parent.mkdir(parents=True, exist_ok=True)
            draw_detections(image, boxes, points).save(target)
            result = {'model': model, 'image': relative.as_posix(), 'size_wh': list(image.size),
                      'input_wh': list(size), 'coordinate_space': 'EXIF-oriented original image pixels',
                      'boxes_xyxy_score': boxes.tolist(), 'landmarks_xy': points.tolist(),
                      'inference_ms': detector.last_ms, 'checkpoint': MANIFEST['models'][model]}
            target.with_suffix('.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
            records.append({'model': model, 'image': relative.as_posix(), 'faces': len(boxes),
                            'inference_ms': detector.last_ms,
                            'annotated_image': target.relative_to(output).as_posix()})
            print(f'{model} [{index}/{len(paths)}] {relative}: {len(boxes)} faces, '
                  f'{detector.last_ms:.1f} ms', flush=True)
        del detector
    columns = ['model', 'image', 'faces', 'inference_ms', 'annotated_image']
    with (output / 'summary.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(records)
    (output / 'errors.json').write_text(json.dumps(errors, indent=2), encoding='utf-8')
    write_gallery(output, records)
    if not records:
        raise RuntimeError('All input images failed to load; see errors.json')
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', choices=['all'] + MODEL_NAMES, default='yunet')
    parser.add_argument('--input', default='images')
    parser.add_argument('--output', default=None)
    parser.add_argument('--size', choices=['480x640', '640x640', '640x480'], default='480x640')
    parser.add_argument('--threads', type=int, default=2)
    parser.add_argument('--confidence', type=float, default=0.5)
    args = parser.parse_args()
    models = [args.model]
    if args.model == 'all':
        models = MODEL_NAMES
    output = args.output
    if output is None:
        output = 'outputs/run_' + time.strftime('%Y%m%d_%H%M%S')
    size = tuple(int(value) for value in args.size.split('x'))
    run_folder(args.input, output, models, size, args.threads, args.confidence)
    print(f'Open: {Path(output).resolve() / "gallery.html"}')


if __name__ == '__main__':
    main()
